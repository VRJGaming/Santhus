import React from 'react';

function About () {
	return <div>
		<h2>This is about us page!</h2>

		Read more about us at :
		<a href="https://www.google.com">
        https://www.google.com
		</a>
	</div>
}
export default About;
