import React from 'react';

function Contact (){
return <address>
			You can find us here:<br />
			Santhosh Address<br />
			I am wait to reach you <br />
			T Andrapradesh vishakapatnam (530016)
		</address>
}

export default Contact;
